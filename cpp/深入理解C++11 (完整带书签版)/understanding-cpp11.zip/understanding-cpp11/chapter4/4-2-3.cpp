#include <string>
#include <vector>

void loopover(std::vector<std::string> & vs) {
    std::vector<std::string>::iterator i = vs.begin(); // iterator，想说爱你并不容易

    for (; i < vs.end(); i++) {
        // 一些代码
    }
}
