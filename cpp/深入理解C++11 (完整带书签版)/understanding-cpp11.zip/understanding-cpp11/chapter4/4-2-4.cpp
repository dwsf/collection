#include <string>
#include <vector>

void loopover(std::vector<std::string> & vs) {

    for (auto i = vs.begin(); i < vs.end(); i++) {
        // 一些代码
    }
}
