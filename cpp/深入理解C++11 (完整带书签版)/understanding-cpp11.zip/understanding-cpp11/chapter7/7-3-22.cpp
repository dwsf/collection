void autoparm(auto a){
    auto auto_param_lambda = [](auto b){};
}

