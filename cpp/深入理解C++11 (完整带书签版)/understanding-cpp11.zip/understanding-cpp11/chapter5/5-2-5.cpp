#include <iostream>
#include <memory>
using namespace std;

int main() {
    cout << get_pointer_safety() << endl;
}
